<?php
$filename= "hello.txt";
// read...
$file= fopen($filename,'r');
echo fread($file,filesize($filename));

//write..
$file = fopen($filename,'w');
fwrite($file,"how are you?....hello coders");"<br>";

//apend...

// $file=fopen($filename,'a');
// fwrite($file,"welcome user");"<br>";

//delete..
// if ( $filename) {
//     unlink($filename);
// }


?>