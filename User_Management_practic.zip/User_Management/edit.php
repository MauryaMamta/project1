<?php
include 'db.php';
$id= isset($_GET["id"])? $_GET["id"]:null;

if ( $id) {
    $sql=$co->prepare("select id,name,email,role from test where id=?");
    $sql->bind_param("i",$id);
    $sql->execute();
    $vari=$sql->get_result()->fetch_assoc();

   if ( $vari) {
          echo "no records found";
    }
}
if ( $_SERVER["REQUEST_METHOD"]=="POST") {
    $id=$_POST["id"];
    $name=$_POST["name"];
    $email=$_POST["email"];
    $role=$_POST["role"];
    $sql_update =$co->prepare("update test set name=?, email=?, role=? where id=? ");
    $sql_update->bind_param("sssi",$name,$email,$role,$id);
if ($sql_update->execute()) {
    header("Location:index.php");
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
<input type="hidden" name="id" value="<?= $vari["id"]?>"><br>
Name:
<input type="text" name="name" id=""value="<?= $vari["name"]?>"><br>
Email:
<input type="email" name="email" id=""value="<?= $vari["email"]?>"><br>
Role:
<input type="text" name="role" id=""value="<?= $vari["role"]?>"><br>
<button type="submit">Submit</button>
<button type="reset">Reset</button>
</form>    

</body>
</html>