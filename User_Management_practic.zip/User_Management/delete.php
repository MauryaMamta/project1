<?php

include 'db.php';
if (isset($_GET["id"])) {
    $id=$_GET["id"];
    $sql=$co->prepare("delete from test where id=?");
    $sql->bind_param("i",$id);
if ( $sql->execute()) {
    header("Location:index.php");
}
}
?>