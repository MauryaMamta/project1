<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Update</h2>

    <form action="" method="post">
Name:
<input type="text" name="name" id=""><br>
Email:
<input type="email" name="email" id=""><br>
Role:
<select name="role" id="">
<option value="Manager">Manager</option>
<option value="Hr">hr</option>
<option value="Developer">developer</option>
<option value="Worker">worker</option>
<option value="Student">student</option>
<option value="IITians">IITians</option>
<option value="Doctor">Doctor</option>
<option value="player">player</option><br>
</select>
<br>
Password:
<input type="text" name="pass" id=""><br>
 <button tyep="submit">Submit</button>

</form>
</body>
</html>

<?php
include 'db.php';
if ( $_SERVER["REQUEST_METHOD"]=="POST") {
    $id=$_POST["id"]; 
    $name=$_POST["name"];
     $email=$_POST["email"];
     $role=$_POST["email"];
     $pass=$_POST["pass"];

     $sql=$co->prepare("update test set name=?,email=?,role=?, password=? where id=?");
$sql->bind_param("ssssi",$name,$email,$role,$pass,$id);

if ($sql->execute()) {
    header("Location:delete.php");
}else {
     header("Location:update.php");
}

}

?>