<?php
include 'db.php';
$result=$co->query("select * from test");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Insert </h3>
    <form action="" method="post">
Name:
<input type="text" name="name" id=""><br>
Email:
<input type="email" name="email" id=""><br>
Role:
<select name="role" id="">
<option value="Manager">Manager</option>
<option value="Hr">hr</option>
<option value="Developer">developer</option>
<option value="Worker">worker</option>
<option value="Student">student</option>
<option value="IITians">IITians</option>
<option value="Doctor">Doctor</option>
<option value="player">player</option><br>
</select>
<br>
Password:
<input type="text" name="pass" id=""><br>
 <button tyep="submit">Submit</button>
    </form>
</body>
</html>
<?php
 include 'db.php';

if ( $_SERVER["REQUEST_METHOD"]=="POST") {
     $name=$_POST["name"];
     $email=$_POST["email"];
     $role=$_POST["role"];
     $pass=password_hash($_POST["pass"],PASSWORD_BCRYPT);

     $sql=$co->prepare("insert  into test(name,email,role,password)values(?,?,?,?)");
$sql->bind_param("ssss",$name,$email,$role,$pass);
if ($sql->execute()) {
    header("Location:index.php");
} 
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>User data</h2>
<table>
<tr></tr>
    <th>Id</th>
    <th>Name</th>
    <th>Email</th>
    <th>Role</th>
</tr>
<?php while($row=$result->fetch_assoc()){?>
        <tr>
        <td><?= $row["id"]?></td>
        <td><?= $row["name"]?></td>
        <td><?= $row["email"]?></td>
        <td><?= $row["role"]?></td>
        <td><a href="edit.php?id=<?=$row["id"]?>">Edit</a> 
        <a href="delete.php?id=<?=$row["id"]?>
        "onclick = "return confirm('Are you sure want to delete')";>Delete</a>
    
    
    </td></tr>   
<?php }?>
</table>    
</body>
</html>